package pcs.mca.atmiya.calculator1;

public interface button {
}
